import './offCanvaCarrinho-estilos.css';

function OffCanvaCarrinho() {
    return (
        <div class="offcanvas offcanvas-end container-area-carrinho" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
            <div className='container-header-carrinho'>
                <h2>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-bag h-5 w-5 text-primary"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
                    Seu Carrinho
                </h2>
                <p>Seu carrinho está vazio.</p>
            </div>
            <div className='container-body-carrinho'>
                <div className='container-svg-carrinho'>
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-bag h-5 w-5 text-primary"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
                </div>
                <p className='container-paragrafo-carrinho'>Adicione produtos para vê-los aqui.</p>
                <button className='container-button-carrinho'>Continuar Comprando</button>
            </div>
        </div>
    )
}

export default OffCanvaCarrinho;